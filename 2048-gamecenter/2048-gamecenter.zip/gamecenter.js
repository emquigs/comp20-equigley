//gamecenter.js API for storing scores


var express = require("express");
var logfmt = require("logfmt");

var app = express();
app.use(express.json());
app.use(express.urlencoded());
app.all('*', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

app.use(logfmt.requestLogger());

var mongo = require("mongodb");
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://mongolab.com:49337/heroku_app23826344';
var db = mongo.Db.connect(mongoUri, function (err, connect) {
		db = connect;
	});

app.post('/submit.json', function(req, res) {

	var username = req.body.username;
	var score = req.body.score;
	score = parseInt(score);
	var grid = req.body.grid;

	var date = new Date();
	var timeStamp = date.toString();

	if (username != "" && score != "" && grid != "") {
		db.collection('scores', function(err, collection) {
			collection.insert(
								{
									"username": username,
									"score": score,
									"grid": grid,
									"created_at": timeStamp
								}, function (err, docs){
									res.send('Your score has been recorded!');
								}
							  );
	 	});
	} else {
		res.send("Sorry, you're missing information!");
	}
});

app.get('/scores.json', function(req, res) {

	var name = req.query.username;

	db.collection('scores', function(err, collection) {
		var data = collection.find({ username: name }).sort({ score: -1 }).toArray(function(err, scoreArray) {
			res.send(scoreArray);
		});
	});
});

app.get('/', function(req, res) {
	var tableString = '<h1>Game Center</h1><h2>2048 High Scoreboard</h2><table border="1"><tr><th>Username</th><th>Score</th><th>Time</th></tr>';

	db.collection('scores', function(er, collection) {
		var data = collection.find({}).sort({ score: -1 }).toArray(function(err, scoreArray) {
			scoreArray.forEach(function (record) {
				var time = record.created_at.substring(0, 24);
				tableString += ('<tr><td>' + record.username + '</td><td>' + record.score + '</td><td>' + time + '</td></tr>');
			});
			tableString += '</table>';
			res.send(tableString);
		});
	});

});

var port = Number(process.env.PORT || 5000);
app.listen(port, function() {
  console.log("Listening on " + port);
});