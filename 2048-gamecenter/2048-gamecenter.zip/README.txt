README.txt - Assignment 4

Heroku app URL: http://shielded-peak-7330.herokuapp.com/

1. All aspects of this project are implemented correctly. If I had more time to perfect it, I would figure out how to use a CSS to style the HTML root page.

2. I collaborated with Emily Taintor and got help from the TA Andrew to better conceptualize this project. I also got help from the TAs Nate and Jasper to help me debug my app once it was deployed.

3. In total, this project took me about 10.5 hours to complete.

4. The score and grid data are used in the game-manager.js file to set up the game, play the game, and end the game. They are stored in their own objects that appear to be classes, with their own methods and instances.

5. I only had to modify two files to be able to send the appropriate information to my app: index.html and game-manager.js. In index.html, I had to include jQuery in a script tag. In game-manager.js, I went into the "isGameTerminated" function and if the check for game terminated is true, I turn the final game grid into a JSON string and then send this, along with the username and score of the final game, in a jQuery post to my app url.